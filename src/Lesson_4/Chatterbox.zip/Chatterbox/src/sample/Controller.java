package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;

public class Controller {
    @FXML
    public TextArea chat;
    @FXML
    public TextField inputString;
    @FXML
    public Button sendButton;

    public void onActionInputString(ActionEvent actionEvent) {
        if (!(inputString.getText().equals(""))) {                  //условие для избежания ввода пустой строки
            chat.appendText(inputString.getText() + "\n");
            inputString.clear();                                    //в чём разница между .clear() и .setText("")???
//        inputString.setText("");
        }
    }

    public void onMouseReleasedSendButton(MouseEvent mouseEvent) { //хотелось сделать именно клик по кнопке, чтобы избежать случайной отправки сообщения вслучае нажатия Tab-пробел
        ActionEvent actionEvent = new ActionEvent();                //не уверен что это элегантное решение, но на mouseEvent писало ошибку
//        chat.appendText(inputString.getText() + "\n");
//        inputString.clear();
        onActionInputString(actionEvent);
    }

}
